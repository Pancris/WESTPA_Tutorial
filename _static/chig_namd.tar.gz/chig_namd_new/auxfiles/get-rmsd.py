from AtomSel import AtomSel
from Molecule import Molecule

mol1=Molecule()
mol1.load('chig.psf')
mol1.load('reference.pdb')
mol1.load('parent.pdb')
mol1.load('seg.dcd')
n = mol1.numFrames()

sel=AtomSel('backbone')

# align all frames with the first frame, using the backbone atoms
for i in range(1,n):
  sel.align(frame=i)

# RMS distance from the first frame.
rms=[]
ref=AtomSel('backbone',frame=0)
for i in xrange(n):
  rms.append(sel.frame(i).align(ref=ref).rmsd(ref))
  print "RMSD: ", rms[i]
