#!/bin/bash

if [ -n "$SEG_DEBUG" ] ; then
    set -x
    env | sort
fi

cd $WEST_SIM_ROOT


# Get progress coordinate
/usr/local/bin/vmd -python -e get-rmsd-init.py >& rmsd.temp || exit 1
grep "RMSD:  " rmsd.temp | gawk '{print $2}' > $WEST_PCOORD_RETURN 
rm -f rmsd.temp

if [ -n "$SEG_DEBUG" ] ; then
    head -v $WEST_PCOORD_RETURN
fi


