#!/bin/bash

if [ -n "$SEG_DEBUG" ] ; then
    set -x
    env | sort
fi

cd $WEST_SIM_ROOT

mkdir -pv $WEST_CURRENT_SEG_DATA_REF || exit 1
cd $WEST_CURRENT_SEG_DATA_REF || exit 1

# Set up the run
ln -sv $WEST_SIM_ROOT/auxfiles/* .

 case $WEST_CURRENT_SEG_INITPOINT_TYPE in
     SEG_INITPOINT_CONTINUES)
         # A continuation from a prior segment
         ln -sv $WEST_PARENT_DATA_REF/seg.coor  ./parent.pdb
         ln -sv $WEST_PARENT_DATA_REF/seg.vel   ./parent.vel
         namd2 md-continue.conf > seg.out 
     ;;
 
     SEG_INITPOINT_NEWTRAJ)
         # Initiation of a new trajectory; $WEST_PARENT_DATA_REF contains the reference to the
         ln -sv seg_initial.pdb  ./parent.pdb 
         ln -sv seg_initial.vel     ./parent.vel 
         namd2 md-continue.conf > seg.out 
     ;;
 
     *)
         echo "unknown init point type $WEST_CURRENT_SEG_INITPOINT_TYPE"
         exit 2
     ;;
 esac


#Get pcoord
vmd -python -e get-rmsd.py >& rmsd.temp 
wait
grep "RMSD:  " rmsd.temp | gawk '{print $2}' | tail -2 > pcoord.dat
wait
cat pcoord.dat > $WEST_PCOORD_RETURN



if [ -n "$SEG_DEBUG" ] ; then
    head -v $WEST_PCOORD_RETURN
fi

# Clean up
rm -f *.conf *.py  seg_restart.* *.prm *.temp *.pdb  *.psf
